# Reproducibility (EXP-CLI-FRAME-REAL-001)

## Reference

- Repository: https://github.com/mattias800/prosper
- Commit tested: `c1d6cd86e689ddb62b97420bebc413ba3371f038`
- Game dump: `PPSA02929-app0` (PS SELF `eboot.bin`, Unity/IL2CPP). The dump is user-supplied and
  gitignored — it is **not** in this package and must be supplied by the reproducer.

## Prerequisites

A C++20 compiler, CMake, Ninja, the Vulkan loader + a usable ICD, and (for the native AvPlayer
backend) FFmpeg. On Debian/Ubuntu:

```bash
sudo apt-get install -y --no-install-recommends \
  ninja-build cmake pkg-config libvulkan-dev spirv-tools \
  mesa-vulkan-drivers \
  libavformat-dev libavcodec-dev libavutil-dev libswresample-dev libswscale-dev libva-dev
```

`mesa-vulkan-drivers` provides the `llvmpipe` software ICD used in this experiment
(`/usr/share/vulkan/icd.d/lvp_icd.json`). Any usable Vulkan ICD works; llvmpipe is the headless one.

## Build

```bash
cmake -S prosper -B prosper/build-linux -G Ninja \
  -DGAME_DUMP=<DUMP_ROOT>/PPSA02929-app0
cmake --build prosper/build-linux -j$(nproc)
```

Expected: the configure log reports `Vulkan found ... — offscreen graphics harness enabled`. If it
instead logs `Vulkan not found`, the host has the loader but no ICD/headers — install
`libvulkan-dev` + `mesa-vulkan-drivers` and re-configure (a no-Vulkan configure succeeds while
silently dropping the graphics harness and every Vulkan execution test).

## Capture the first real frame

```bash
export VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/lvp_icd.json   # llvmpipe
export PROSPER_RENDER=1
export XDG_RUNTIME_DIR=<scratch dir>            # any writable dir; keeps the loader happy
mkdir -p <scratch>

./prosper/build-linux/boot_trace <DUMP_ROOT>/PPSA02929-app0 \
  --capture-first-frame PPSA02929_first_frame.bmp
echo "exit: $?"
```

- Exit code `0` → a real frame was captured (`REAL FRAME CAPTURED`).
- Exit code `2` → no real frame was presented within the timeout (`NO_REAL_FRAME_PRESENTED`). Check
  the log for `[render] Vulkan device: ...`; an empty ICD set produces zero-pixel output.

## Verify the captured frame is real

```bash
# The capture report (exit 0 means FRAME CAPTURE: PASS)
cat PPSA02929_first_frame.bmp.report.txt | grep -E "source|REAL PRESENT|FRAME CAPTURE"

# Non-zero pixel check (a real frame is not a black/clear-only buffer)
python3 - <<'PY'
import struct
with open('PPSA02929_first_frame.bmp','rb') as f:
    h=f.read(54); off=struct.unpack('<I',h[10:14])[0]; f.seek(off); d=f.read()
nz=sum(1 for b in d if b!=0)
print(f'non-zero: {nz}/{len(d)} ({100*nz/len(d):.2f}%)')
PY
```

Expected: `source: Rendered`, `REAL PRESENT: PASS`, `FRAME CAPTURE: PASS`, non-zero ~100%.

## Expected variation across runs

- `wait_time` and the exact boot log lines may vary slightly run-to-run (guest scheduling), but the
  first present frame is reached reliably in this configuration (exit 0 across re-runs).
- The BMP header reports the present target's full 3840×2160 extent; the first-frame capture exits
  the guest after ~1929 complete rows of pixel data have been written (33,177,654 bytes). The PNG in
  this package encodes those complete rows (3840×1929).

## What a reproducer needs to supply

- The legally-obtained `PPSA02929-app0` dump (eboot.bin + assets). Prosper and this package
  redistribute no game files, assets, keys, or firmware.
- A usable Vulkan ICD (llvmpipe is the headless option validated here).
