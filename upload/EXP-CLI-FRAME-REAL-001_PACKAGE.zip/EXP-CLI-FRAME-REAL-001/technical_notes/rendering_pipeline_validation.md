# Rendering-pipeline validation (EXP-CLI-FRAME-REAL-001)

## The end-to-end path this capture validates

A non-synthetic frame with `source: Rendered` is positive evidence that the **entire** Prosper
rendering spine executed for this title, because the observer can only obtain such a frame if every
link in the chain produced real output:

```
Game boot
  →  guest execution  (native x86-64; SELF/ELF parsed, modules linked, NID imports resolved,
                      Sony CRT + C++ global ctors run, IL2CPP runtime + GC + worker pool started)
  →  AGC / render submission  (guest issues AGC command streams; PM4 decode + command processor +
                      render state + the RDNA2→SPIR-V shader recompiler + resource binding)
  →  Vulkan renderer  (AGC→Vulkan translation onto the live Vulkan device — here llvmpipe)
  →  render target  (color target realized, draws composite into it)
  →  VideoOut / present  (the composited frame is handed to the present path)
  →  rendered frame snapshot  (present_snapshot reads the frame back)
  →  image capture  (the observer writes the BMP + the EXP-CLI-FRAME-REAL-001 report)
```

If any earlier link had failed (no boot, no guest execution, no AGC submission, no Vulkan device, no
draws, no present), the observer would report `NO_REAL_FRAME_PRESENTED` and exit code 2. The observed
exit code 0, the `RENDERER FRAME DETECTED` line, and `source: Rendered` together mean the chain ran
end to end for this title.

## What was observed at boot (from the runtime log)

Representative milestones reached before the first present, in order:

- Module link: 2 modules, 587 imports (170 cross-module, 383 stub slots), 1 init function.
- `libSceUlt` (user-level threading) initialized; ulthreads run one-to-one on real guest threads.
- `libSceSaveData_native` mount/unmount calls dispatched.
- `libSceNpUniversalDataSystem` dispatched.
- AGC register defaults requested for SDK version 8.
- VideoOut scanout baseline seeded (3840×2160).
- AudioOut started (port#1, 256 samples, 48000 Hz, 2 channels).
- SpriteMachine shader load (`shaders/SpriteMachine.vert` + `.frag`) and builtin shader file probes.
- Persistent GPU color targets / texture-image residency budgets established.
- `[first-frame] RENDERER FRAME DETECTED at 0.332s (seq=1)`.

## Why "Rendered" matters

`source: Rendered` (as opposed to a synthetic/clear/test-pattern source) is the discriminator that
makes this a real-frame milestone rather than a renderer-harness smoke test. The Prosper frontend's
test-pattern path exists and is useful for front-end validation, but this experiment specifically did
**not** use it; the frame came from the guest's own present output.

## Determinism note

llvmpipe is a deterministic software rasterizer (Prosper's CI relies on this for its golden-hash
render gate). This makes the rendering portion of this run reproducible on the same commit + ICD;
the guest boot order itself can vary slightly run-to-run, but the *first* present frame on this
title is reached reliably in this configuration (exit 0 across re-runs).
