# CLI capabilities demonstrated by EXP-CLI-FRAME-REAL-001

This document records **only** what the Prosper CLI was demonstrated to do in this experiment. It
deliberately separates **demonstrated capability** from **future/planned capability**, and does not
claim anything not evidenced by the capture run.

## Demonstrated in this run

The `boot_trace` CLI, with the `--capture-first-frame` observer, demonstrated:

- **CLI-based game boot** — the title's SELF/ELF modules are linked and the guest program is started
  from the command line, with no windowed frontend required.
- **Headless / diagnostic execution** — the run needs no display server. The Vulkan device is the
  `llvmpipe` software ICD (`Vulkan device: llvmpipe (LLVM 19.1.7, 256 bits) (CPU)`), so the path runs
  on a headless machine.
- **Runtime diagnostics** — the unimplemented-call trace is emitted to stderr (e.g. unimplemented
  `libkernel`, `libSceSaveData_native`, `libSceNpUniversalDataSystem` NIDs), and on a fault the tool
  reports register state plus an `rbp`-chain backtrace classified by module.
- **VideoOut / present-path observation** — the observer hooks the existing `present_snapshot` path,
  so a frame is only captured when the guest actually reaches and writes the present target.
- **First-real-frame detection and capture** — `[first-frame] RENDERER FRAME DETECTED at 0.332s
  (seq=1)`; the tool waits for the first frame from the present path, then writes the BMP.
- **Frame metadata collection** — the capture report records `width`, `height`, `pitch`, `format`,
  `frame_seq`, `present_count`, `front_index`, `source`, `bytes_written`, `wait_time`.
- **Non-invasive, observer-only capture architecture** — the capture code (`first_frame_capture`)
  is documented as observer-only; it does **not** modify the renderer or runtime behavior, and the
  report states `Synthetic/fake data used: NO`.
- **Evidence-oriented debugging** — the tool emits a structured `EXP-CLI-FRAME-REAL-001`-style
  report alongside the image, so a reviewer can verify BOOT/RUNTIME/REAL_PRESENT/FRAME_CAPTURE
  independently of the image bytes.
- **Validation of the complete boot → render → present path without the original development
  environment** — because the frame came from the real `Rendered` source, a non-zero, non-test-pattern
  image is positive evidence that the whole spine executed.

## What `--capture-first-frame` is (and is not)

- It **is** an **observer / capture** feature. It enables the existing live renderer
  (`PROSPER_RENDER=1`), runs the guest on a thread, and waits for the first real frame from the
  present path. The captured frame's `source` is `Rendered`.
- It is **not** a synthetic renderer, a fake-frame generator, or a test-pattern emitter. A
  `--test-pattern` path exists separately in the frontend; this experiment did **not** use it.

## Vulkan environment used for this experiment

A usable Vulkan ICD / software Vulkan implementation is required for actual rendering. This
experiment used the **`llvmpipe`** software Vulkan ICD (`mesa-vulkan-drivers`, the same ICD the
Prosper CI uses for its headless Vulkan-execution tests). It produced a working Vulkan device and the
real frame above.

This is the **validated environment used for this experiment**, not the only possible one. The
relevant requirement is: a usable Vulkan ICD must be present so the loader can actually create a
device. An empty `/etc/vulkan/icd.d/` (loader present, no driver) yields zero-pixel output and is the
historical reason a "capture" can look successful while producing no real frame.

## Explicitly NOT claimed

- This run does **not** prove all PS5 games work.
- It does **not** prove Prosper is fully compatible.
- It does **not** prove all rendering paths work.
- It does **not** prove production-ready performance.
- It does **not** prove every Vulkan configuration works.
- It does **not** prove every game can currently produce a frame.

The exact, verified claim is:

> PPSA02929 successfully booted through the Prosper CLI and produced a real rendered 3840×2160
> frame using the first-frame capture observer.
