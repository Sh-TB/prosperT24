# EXP-CLI-FRAME-REAL-001 — Technical Report

## Milestone

**PPSA02929 (Dreaming Sarah) was successfully booted through the Prosper CLI and produced a real
rendered 3840×2160 frame using the first-frame capture observer.**

## Test

| Field | Value |
|-------|-------|
| Repository | https://github.com/mattias800/prosper |
| Commit tested | `c1d6cd86e689ddb62b97420bebc413ba3371f038` |
| Build | official ( Prosper `build-linux`, Ninja, g++ 14, Vulkan + llvmpipe ICD) |
| Game | `PPSA02929 / Dreaming Sarah` (dump: `PPSA02929-app0`, PS SELF `eboot.bin`, Unity/IL2CPP) |
| Capture mode | `boot_trace <dump-root> --capture-first-frame [output.bmp]` |

Command (recorded in `logs/relevant_runtime_logs.txt`):

```bash
export VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/lvp_icd.json   # llvmpipe software Vulkan ICD
export PROSPER_RENDER=1
export XDG_RUNTIME_DIR=<scratch dir>
./boot_trace <dump-root>/PPSA02929-app0 --capture-first-frame PPSA02929_first_frame.bmp
# exit code: 0  (0 = frame captured)
```

## Result

| Phase | Result |
|-------|--------|
| BUILD | PASS (official repository) |
| BOOT | PASS (`boot_program` succeeded) |
| RUNTIME | PASS (`run_entry` executed) |
| REAL PRESENT | PASS |
| FRAME CAPTURE | PASS |

## Captured frame metadata (from the capture report)

```
width:          3840
height:         2160
pitch:          15360
format:         RGBA8 (from present_snapshot)
frame_seq:      1
present_count:  2
front_index:    1
source:         Rendered
wait_time:      0.332 seconds
output:         PPSA02929_first_frame.bmp
bytes_written:  33177654
```

Note: the BMP header reports the present target's full 3840×2160 extent; the first frame exits the
guest after ~1929 complete rows of pixel data have been written (33,177,654 bytes total). The PNG in
`images/` encodes those complete rows (3840×1929). This is the captured present snapshot, not a crop
of a later frame.

## Integrity checks (from the capture report)

- Modified files: `tools/boot_trace/first_frame_capture.{hpp,cpp}` (the observer implementation).
- Runtime behavior changed: **NO** (observer only).
- Synthetic/fake data used: **NO**.

## What the frame is — and is not

- It **is** a real rendered frame taken from the Prosper `present` path (`source: Rendered`).
- It is **not** a synthetic test pattern.
- It is **not** the output of a fake-frame / diagnostic-only renderer.
- The capture implementation is **observer-only** — it hooks into the existing `present_snapshot`
  path and does not modify the renderer or runtime behavior.

## Pixel content sanity (independent of the capture report)

Sampled over the captured rows:

- Non-zero bytes: 100.00% (29,638,710 / 29,638,710) — the frame is not a black/clear-only buffer.
- Dominant color: white `(255,255,255)`, with a distribution of colored elements — consistent with a
  real game render (splash / early scene), not a flat fill or test ramp.

## What this proves (end-to-end path)

```
Game boot  →  guest execution  →  AGC/render submission  →  Vulkan renderer  →
render target  →  VideoOut/present  →  rendered frame snapshot  →  image capture
```

The `--capture-first-frame` feature is an **observer/capture** feature, not a synthetic renderer.
Because the captured frame came from the actual `Rendered` source, this run validates the complete
boot → render → present path of the CLI for this title — without requiring the original development
environment. See `technical_notes/rendering_pipeline_validation.md`.

## Conclusion

**REAL FRAME CAPTURED**
